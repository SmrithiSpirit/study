import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
      <div className="container">
        <div className="mt-5"></div>
        <p>home works!</p>
      </div>
    );
  }
}

export default Home;
