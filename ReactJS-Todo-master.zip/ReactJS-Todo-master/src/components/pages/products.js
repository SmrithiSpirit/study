import React, { Component } from 'react';

class Products extends Component {
  render() {
    return (
      <div className="container">
        <div className="mt-5"></div>
        <p>products works!</p>
      </div>
    );
  }
}

export default Products;
